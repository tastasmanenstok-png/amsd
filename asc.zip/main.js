// src/main.js

const { app, BrowserWindow, ipcMain, dialog } = require('electron');
const path = require('path');
const fs = require('fs'); // Ditambahkan
const axios = require('axios');
const dns = require('dns').promises; // Ditambahkan

// --- Konfigurasi Azure CNAMEs ---
const AZURE_CNAMES = [
  '.cloudapp.net', '.cloudapp.azure.com', '.azurewebsites.net', 
  '.blob.core.windows.net', '.trafficmanager.net',
  '.database.windows.net', '.redis.cache.windows.net'
];

function createWindow() {
  // Pengaturan jendela dari versi premium dipertahankan
  const mainWindow = new BrowserWindow({
    width: 950, // Disesuaikan untuk dasbor
    height: 700,
    frame: false,
    transparent: true,
    backgroundColor: '#00FFFFFF',
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
    },
  });

  mainWindow.loadFile(path.join(__dirname, 'src/index.html'));
  
  // Kontrol jendela kustom
  ipcMain.on('minimize-window', () => mainWindow.minimize());
  ipcMain.on('maximize-window', () => mainWindow.isMaximized() ? mainWindow.unmaximize() : mainWindow.maximize());
  ipcMain.on('close-window', () => mainWindow.close());
}

app.whenReady().then(createWindow);
app.on('window-all-closed', () => process.platform !== 'darwin' && app.quit());

// IPC untuk mengambil daftar domain (tidak berubah)
ipcMain.handle('fetch-domains', async (event, ip) => {
  try {
    const res = await axios.get(`https://api.reverseipdomain.com/?ip=${ip}`, {
      headers: { 'User-Agent': 'Mozilla/5.0' },
      timeout: 20000,
    });
    return { success: true, data: res.data };
  } catch (err) {
    return { success: false, error: err.message ?? String(err) };
  }
});

// --- IPC BARU: Untuk memeriksa kerentanan domain ---
ipcMain.handle('check-domain-vulnerability', async (event, domain) => {
  try {
    const cnames = await dns.resolveCname(domain);
    const targetCname = cnames[0];
    const isAzureCname = AZURE_CNAMES.some(az => targetCname.endsWith(az));
    if (!isAzureCname) {
      return { domain, status: 'Safe', cname: targetCname, reason: 'Bukan CNAME Azure.' };
    }
    try {
      await dns.resolve(targetCname);
      return { domain, status: 'Safe', cname: targetCname, reason: 'CNAME aktif.' };
    } catch (resolveError) {
      if (resolveError.code === 'ENOTFOUND' || resolveError.code === 'ENODATA') {
        return { domain, status: 'Vulnerable', cname: targetCname, reason: 'CNAME menunjuk ke resource Azure yang tidak ada (NXDOMAIN).' };
      }
      return { domain, status: 'Unknown', cname: targetCname, reason: 'Gagal verifikasi CNAME.' };
    }
  } catch (err) {
    if (err.code === 'ENOTFOUND' || err.code === 'ENODATA') {
      return { domain, status: 'Safe', cname: 'N/A', reason: 'Tidak ada CNAME.' };
    }
    return { domain, status: 'Error', cname: 'N/A', reason: `DNS Gagal: ${err.code}` };
  }
});

// --- IPC BARU: Untuk penyimpanan otomatis ---
ipcMain.handle('auto-save-results', (event, { filename, content }) => {
  try {
    const desktopPath = app.getPath('desktop');
    const filePath = path.join(desktopPath, filename);
    fs.writeFileSync(filePath, content, 'utf8');
    return { success: true, path: filePath };
  } catch (error) {
    return { success: false, error: error.message };
  }
});