// src/preload.js

const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('api', {
  // Fungsi yang sudah ada
  fetchDomains: (ip) => ipcRenderer.invoke('fetch-domains', ip),
  
  // Fungsi baru ditambahkan
  checkDomainVulnerability: (domain) => ipcRenderer.invoke('check-domain-vulnerability', domain),
  autoSaveResults: (data) => ipcRenderer.invoke('auto-save-results', data)
});

contextBridge.exposeInMainWorld('controls', {
  minimize: () => ipcRenderer.send('minimize-window'),
  maximize: () => ipcRenderer.send('maximize-window'),
  close: () => ipcRenderer.send('close-window'),
});