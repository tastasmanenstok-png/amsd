// src/renderer.js

document.addEventListener('DOMContentLoaded', () => {
    // Elemen UI
    const ipInput = document.getElementById('ip-input');
    const scanButton = document.getElementById('scan-button');
    const statusSpan = document.getElementById('scan-status');
    const resultsBody = document.getElementById('results-body');
    const progressIndicator = document.getElementById('progress-indicator');

    // Elemen Statistik
    const totalValue = document.getElementById('total-value');
    const scannedValue = document.getElementById('scanned-value');
    const vulnValue = document.getElementById('vuln-value');

    // Kontrol Jendela
    document.getElementById('minimize-btn').addEventListener('click', () => controls.minimize());
    document.getElementById('maximize-btn').addEventListener('click', () => controls.maximize());
    document.getElementById('close-btn').addEventListener('click', () => controls.close());
    
    let fullResults = [];

    const setStatus = (message, type = '', isLoading = false) => {
        statusSpan.textContent = message;
        statusSpan.className = `status ${type}`;
        isLoading ? statusSpan.classList.add('loading-indicator') : statusSpan.classList.remove('loading-indicator');
    };

    scanButton.addEventListener('click', async () => {
        const ip = ipInput.value.trim();
        if (!ip) {
            setStatus('Alamat IP tidak boleh kosong!', 'error');
            return;
        }

        // --- Inisialisasi & Reset UI ---
        scanButton.disabled = true;
        setStatus('Mengambil daftar domain...', '', true);
        progressIndicator.style.width = '0%';
        resultsBody.innerHTML = '';
        totalValue.textContent = '...';
        scannedValue.textContent = '0';
        vulnValue.textContent = '0';
        fullResults = [];

        // --- Langkah 1: Ambil Daftar Domain ---
        const domainResponse = await window.api.fetchDomains(ip);

        if (!domainResponse.success || !domainResponse.data.result || domainResponse.data.result.length === 0) {
            setStatus(domainResponse.error || 'Tidak ada domain ditemukan.', 'error');
            scanButton.disabled = false;
            totalValue.textContent = '0';
            return;
        }

        const domainsToScan = domainResponse.data.result;
        const totalDomains = domainsToScan.length;
        totalValue.textContent = totalDomains;

        // --- Langkah 2: Pindai Setiap Domain ---
        let scannedCount = 0, vulnFound = 0;

        for (const domain of domainsToScan) {
            scannedCount++;
            setStatus(`Memindai ${scannedCount}/${totalDomains}: ${domain}`, '', true);
            
            const result = await window.api.checkDomainVulnerability(domain);
            fullResults.push(result);

            scannedValue.textContent = scannedCount;
            if (result.status === 'Vulnerable') {
                vulnFound++;
                vulnValue.textContent = vulnFound;
            }

            // Tambahkan hasil ke tabel UI secara real-time
            const row = document.createElement('tr');
            row.innerHTML = `
                <td>${result.domain}</td>
                <td><span class="status-badge status-${result.status}">${result.status}</span></td>
                <td>${result.cname || 'N/A'}</td>
            `;
            resultsBody.prepend(row); // Prepend agar hasil terbaru selalu di atas

            progressIndicator.style.width = `${(scannedCount / totalDomains) * 100}%`;
        }

        // --- Langkah 3: Selesaikan dan Simpan Otomatis ---
        setStatus(`Pemindaian selesai! Ditemukan ${vulnFound} kerentanan.`, 'success');
        await autoSave(ip);
        scanButton.disabled = false;
    });

    async function autoSave(ip) {
        if (fullResults.length === 0) return;
        
        let fileContent = `Hasil Pemindaian untuk IP: ${ip}\n` +
                          `Total Domain: ${fullResults.length}\n` +
                          `Kerentanan Ditemukan: ${vulnValue.textContent}\n` +
                          '============================================\n\n';
        
        fullResults.forEach(r => {
            fileContent += `Domain: ${r.domain}\n` +
                           `Status: ${r.status}\n` +
                           `CNAME: ${r.cname || 'N/A'}\n` +
                           `Keterangan: ${r.reason || ''}\n` +
                           `----------------------------------------\n`;
        });

        const timestamp = new Date().getTime();
        const filename = `scan_results_${ip.replace(/\./g, '_')}_${timestamp}.txt`;

        const saveResult = await window.api.autoSaveResults({ filename, content: fileContent });
        
        if (saveResult.success) {
            setStatus(`Selesai! Hasil disimpan di Desktop Anda.`, 'success');
        } else {
            setStatus(`Pemindaian selesai, tetapi gagal menyimpan file otomatis.`, 'error');
        }
    }
});